#include <stdio.h>

int main() {

  printf("Hello\n");
  printf("World\n");

  return 0;
}
